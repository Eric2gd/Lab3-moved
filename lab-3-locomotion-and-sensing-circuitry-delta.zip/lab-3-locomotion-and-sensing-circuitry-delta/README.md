# Lab 3: Wall Followe

### By: Circuitry Delta
### Date: 13/02/2025
### CS3353: Introduction to AI and Robotics


## Description


## Requirements
- Ros2 jazzy
- Ubuntu 24.04
- Gazebo Garden

## Setup
- Create your Workspace using `mkdir <your_workspace>_ws`
- Enter the workspace using `cd <your_workspace>_ws`
- Create a source file using `mkdir src` and enter it using `cd src`
- Clone the repository in your workspace using `git clone https://github.com/Ashesi-Robotics/lab-3-locomotion-and-sensing-circuitry-delta.git`
- Go back to your workspace `cd ..`
- Build the package using the command `colcon build` directly from the workspace
- Source the install file using the comand `source install/setup.bash`


## View robot using rviz
- Go to your workspace `cd directory/to/your/ws`
- Build the package `colcon build`
- Source the build `source install/setup.bash`
- Launch the Wall follower visualiser `ros2 launch WallFollower rviz.launch.py`
- You can terminate the visualiser by `Ctrl`+`C`




## References


## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.


[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/2OUhlDdl)


[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/VKQmO6tl)
