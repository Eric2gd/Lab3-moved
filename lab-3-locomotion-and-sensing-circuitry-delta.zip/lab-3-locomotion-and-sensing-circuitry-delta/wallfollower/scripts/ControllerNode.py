# Libraries and Dependencies
import rclpy as ros2
from geometry_msgs.msg import Twist
import time
from rclpy.node import Node



#!/usr/bin/env python3

import rospy


class ContollerNode(Node):
    def __init__(self):
        super().init('controller_node')
        self.subscriber=self.create_subscription(Twist,'cmd_vel',self.callback,10)
        
        
        def subscribe(self,msg):
            self.get_logger().info(msg)
