"""
File: spawn.launch.py
Project: AshBot Description
File Created: Saturday, 25th January 2025 1:34:41 PM
Author: nknab
Email: kojo.anyinam-boateng@alumni.ashesi.edu.gh
Version: 1.0
Brief: Launch file to spawn a robot in Gazebo
-----
Last Modified: Saturday, 25th January 2025 10:11:23 PM
Modified By: nknab
-----
Copyright ©2025 nknab
"""

import shutil
import tempfile
from os.path import join

from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

from launch import LaunchContext, LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    OpaqueFunction,
    RegisterEventHandler,
    TimerAction,
)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration

# CONSTANTS
PACKAGE_NAME = "wallfollower"
WAIT_PERIOD = 10.0

def launch_setup(context: LaunchContext) -> list:

    # Get the package share directory
    pkg_share = FindPackageShare(package=PACKAGE_NAME).find(PACKAGE_NAME)

    # Get the launch configuration variables
    use_ros2_control = LaunchConfiguration("use_ros2_control").perform(context)
    world = LaunchConfiguration("world").perform(context)

    # Spawn robot at the given position
    x = LaunchConfiguration("x").perform(context)
    y = LaunchConfiguration("y").perform(context)
    z = LaunchConfiguration("z").perform(context)
    roll = LaunchConfiguration("roll").perform(context)
    pitch = LaunchConfiguration("pitch").perform(context)
    yaw = LaunchConfiguration("yaw").perform(context)

    # Robot State Publisher node
    rsp = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([join(pkg_share, "launch", "rviz.launch.py")]),
        launch_arguments={
            "sim_mode": "true",
            "use_ros2_control": use_ros2_control,
        }.items(),
    )

    # Gazebo launch file
    world_filepath = join(pkg_share, "worlds", f"{world}.world")
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [
                join(
                    get_package_share_directory("ros_gz_sim"),
                    "launch",
                    "gz_sim.launch.py",
                )
            ]
        ),
        launch_arguments={
            "gz_args": ["-r -v4 ", world_filepath],
            "on_exit_shutdown": "true",
        }.items(),
    )

    # Spawn the robot in Gazebo
    spawn_entity = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-topic",
            "robot_description",
            "-name",
            "wallfollower",
            "-x",
            str(x),
            "-y",
            str(y),
            "-z",
            str(z),
            "-R",
            str(roll),
            "-P",
            str(pitch),
            "-Y",
            str(yaw),
        ],
        output="screen",
    )

    # ROS-Gazebo bridge
    bridge_params = join(pkg_share, "config", "gz_bridge.yaml")
    ros_gz_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            "--ros-args",
            "-p",
            f"config_file:={bridge_params}",
        ],
    )

    launch_nodes = [rsp, gazebo, spawn_entity, ros_gz_bridge]

    if use_ros2_control == "true":
        # Spawn the controller manager
        drive_train_spawner = RegisterEventHandler(
            event_handler=OnProcessExit(  # Wait for the robot to spawn
                target_action=spawn_entity,
                on_exit=[
                    TimerAction(
                        period=WAIT_PERIOD,
                        actions=[
                            Node(
                                package="controller_manager",
                                executable="spawner",
                                arguments=[
                                    "diff_controller",
                                    "--controller-ros-args",
                                    "-r /diff_controller/cmd_vel:=/cmd_vel",
                                ],
                            )
                        ],
                    )
                ],
            )
        )

        # Spawn the joint state publisher
        joint_broad_spawner = RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[
                    TimerAction(
                        period=WAIT_PERIOD,
                        actions=[
                            Node(
                                package="controller_manager",
                                executable="spawner",
                                arguments=["joint_broad"],
                            )
                        ],
                    )
                ],
            )
        )

        launch_nodes.extend([drive_train_spawner, joint_broad_spawner])

    return launch_nodes


def generate_launch_description() -> LaunchDescription:
    """
    Launch file to spawn a ashbot robot in Gazebo

    Returns
    -------
    LaunchDescription
        The launch description

    """

    return LaunchDescription(
        [
            DeclareLaunchArgument("x", default_value="0", description="X position of the robot"),
            DeclareLaunchArgument("y", default_value="0", description="Y position of the robot"),
            DeclareLaunchArgument("z", default_value="0.056", description="Z position of the robot"),
            DeclareLaunchArgument("roll", default_value="0", description="Roll position of the robot"),
            DeclareLaunchArgument("pitch", default_value="0", description="Pitch position of the robot"),
            DeclareLaunchArgument("yaw", default_value="0", description="Yaw position of the robot"),
            DeclareLaunchArgument("use_ros2_control", default_value="true", choices=["true", "false"], description="Use ros2_control if true"),
            DeclareLaunchArgument("world", default_value="simple", description="The name of the World to load"),
            OpaqueFunction(function=launch_setup),
        ]
    )