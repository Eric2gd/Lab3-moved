
# imports: 
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
import launch
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node


# launch description function
def generate_launch_description():
    
    # Data input
    urdf_file_name = 'robot.urdf.xacro'
    package_description = 'wallfollower'
   
   
    # data input end
   
    # getting URDF file path
    robot_desc_path = os.path.join(get_package_share_directory(package_description), 'urdf', urdf_file_name)# getting URDF file path from the urdf folder
   
    # robot state publisher node
    robot_state_publisher_node = Node(
         package='robot_state_publisher',
         executable='robot_state_publisher',
         name='robot_state_publisher',
         output='screen',
         emulate_tty=True,# emulate tty: this is used to print the output in the terminal. tty--> teletypewriter
         parameters=[{'use_sim_time': True,'robot_description':Command(['xacro ',robot_desc_path])}],
         respawn=True
    )
    #joint state publisher node
    joint_state_publisher_node = Node(
     package='joint_state_publisher_gui',
     executable='joint_state_publisher_gui',
     name='joint_state_publisher_gui',
     # output='screen',
     # parameters=[{'use_sim_time': True, 'publish_default_positions': True}]
     )
#    
# )

    
    #rviz node
    rviz_node=Node(
        package='rviz2',
        executable='rviz2',
        name='rviz_node',
        output='screen',
     #    parameters=[{'use_sim_time': True}],
        arguments=['-d', os.path.join(get_package_share_directory(package_description), 'rviz', 'bot_config.rviz')]
    )    
    # return launch description
    return LaunchDescription(
         [
        robot_state_publisher_node,
        joint_state_publisher_node,
        rviz_node
    ]
    )