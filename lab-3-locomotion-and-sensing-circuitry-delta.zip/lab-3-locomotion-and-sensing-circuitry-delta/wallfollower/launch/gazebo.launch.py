import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration, Command
from launch.actions import DeclareLaunchArgument
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
import xacro



def generate_launch_description():
    # GPackage name
    PACKAGE_NAME = 'wallfollower'
    
    # Robot name
    robotName = 'WallFollower'

    # Declare Launch Argument for sim_time
    use_sim_time = LaunchConfiguration('use_sim_time')

    # Path to the URDF file
    path_to_urdf = os.path.join(
        get_package_share_directory(PACKAGE_NAME), 'urdf', 'robot.urdf.xacro'
    )
    
    # world file
    world = os.path.join(
        get_package_share_directory(PACKAGE_NAME), "worlds", "my_world.sdf"
    )
    
    #robot description
    robot_descr=xacro.process_file(path_to_urdf).toxml()
    
    #sim time
    use_sim_time = True
    
    
    #Gazebo launch
    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory("ros_gz_sim"),
                "launch",
                "gz_sim.launch.py",
            )
        ),
        launch_arguments={"gz_args":world
            }.items(),
    )
    
    # spawn robot
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-topic', 'robot_description',
            '-entity', robotName,'-x','0','-y','0','-z','0.5'],
        output='screen',
    )
    
    
    # Create a robot_state_publisher node
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': ParameterValue(Command(['xacro ', str(path_to_urdf)]), value_type=str),
            'use_sim_time': use_sim_time
        }]
    )
    #joint_state_publisher
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        output='screen',
        parameters=[{
            'use_sim_time': use_sim_time
        }]
    )
    
    
    # Enable the keyboard for robot control
    keyboard_teleop_node = Node(
        package='teleop_twist_keyboard',
        executable='teleop_twist_keyboard',
        name='teleop_twist_keyboard',
        output='screen'
    )
    
    
    # return the launch description
    return LaunchDescription([
        robot_state_publisher_node,
        joint_state_publisher_node,
        gz_sim,
        spawn_entity
        
    ])